package com.siteazure.demo.serviceimpl;

import java.awt.*;
import java.io.IOException;

import org.dom4j.DocumentException;
import org.suren.autotest.web.framework.settings.SettingUtil;
import org.xml.sax.SAXException;

import com.siteazure.demo.page.ClickMenuPage;
import com.siteazure.demo.util.ScreenShot;

public class ClickMenuServiceImpl {

	public ClickMenuServiceImpl() throws IOException, DocumentException, SAXException, InterruptedException {
		// TODO Auto-generated constructor stub
		ScreenShot cam= new ScreenShot("e:\\Hello\\site", "png");//
		SettingUtil util = new SettingUtil();
		util.readFromClassPath("clickmenu.xml"); //加载元素定位配置文件
		ClickMenuPage clickmenupage=util.getPage(ClickMenuPage.class);
		clickmenupage.open();
		//clickmenupage.getParentNode().click();	
		 Thread.sleep(3000);
		try {
			cam.snapShot();
		} catch (AWTException e) {
			e.printStackTrace();
		}
		//clickmenupage.getChirldrenNode_First().click();
		Thread.sleep(4000);
		try {
			cam.snapShot();
		} catch (AWTException e) {
			e.printStackTrace();
		}
		//clickmenupage.getChirldrenNode_Two().click();
		Thread.sleep(4000);
		try {
			cam.snapShot();
		} catch (AWTException e) {
			e.printStackTrace();
		}

		util.close(); //关闭框架
	}

}
