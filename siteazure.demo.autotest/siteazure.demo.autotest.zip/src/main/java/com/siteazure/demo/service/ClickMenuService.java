package com.siteazure.demo.service;

public interface ClickMenuService {

	public void ClicMenu();
}
