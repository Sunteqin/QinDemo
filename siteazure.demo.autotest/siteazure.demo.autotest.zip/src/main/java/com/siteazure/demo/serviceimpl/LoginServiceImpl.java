package com.siteazure.demo.serviceimpl;

import java.io.IOException;

import org.dom4j.DocumentException;
import org.suren.autotest.web.framework.settings.SettingUtil;
import org.xml.sax.SAXException;

import com.siteazure.demo.page.LoginPage;
import com.siteazure.demo.util.ScreenShot;

public class LoginServiceImpl {

	public LoginServiceImpl() throws IOException, DocumentException, SAXException, InterruptedException {
		
		 
       
	}

}
