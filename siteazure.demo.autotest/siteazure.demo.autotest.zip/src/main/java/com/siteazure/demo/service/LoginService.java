package com.siteazure.demo.service;

import com.siteazure.demo.page.LoginPage;

public interface LoginService {
	
	
	    //登录的方法
		public void addDept(LoginPage loginpage);

}
