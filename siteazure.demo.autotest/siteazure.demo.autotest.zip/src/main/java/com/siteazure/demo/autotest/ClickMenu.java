package com.siteazure.demo.autotest;

import java.io.IOException;

import org.dom4j.DocumentException;
import org.suren.autotest.web.framework.page.Page;
import org.suren.autotest.web.framework.settings.SettingUtil;
import org.xml.sax.SAXException;

import com.siteazure.demo.page.ClickMenuPage;
import com.siteazure.demo.page.LoginPage;

public class ClickMenu {
	
	public static void main(String[] args) throws IOException, DocumentException, SAXException{
		SettingUtil util = new SettingUtil();
		util.readFromClassPath("clickmenu.xml"); //加载元素定位配置文件
		ClickMenuPage clickmenupage=util.getPage(ClickMenuPage.class);
		clickmenupage.open();
		//clickmenupage.getParentNode().click();	
		//clickmenupage.getChirldrenNode_First().click();
	}

	
}
