package com.siteazure.demo.autotest;

import com.siteazure.demo.util.FileUtils;

/**
 * Created by family-sunte on 2017/6/3.
 */
public class FileTest {



    public static void main (String [] args){
        FileUtils.judeDirExists("");
    }
}
