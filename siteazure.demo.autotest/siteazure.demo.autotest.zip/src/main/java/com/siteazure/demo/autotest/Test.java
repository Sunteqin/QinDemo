package com.siteazure.demo.autotest;


import java.io.IOException;

import org.dom4j.DocumentException;
import org.suren.autotest.web.framework.settings.SettingUtil;
import org.xml.sax.SAXException;

import com.siteazure.demo.page.BaiduHomePage;
import com.siteazure.demo.util.*;

/**
 * AutoTest框架的一个简单示例</br>
 * baidu.xml主要包含元素定位信息的描述</br>
 * applicationContext.xml配置了Page类所在的包（package）</br>
 * Page类BaiduHomePage是一个逻辑的页面对象，包括页面中需要定位的元素
 * @author suren
 * @date 2016年12月13日 下午7:52:06
 */
public class Test {

	/**
	 * 入口函数
	 * @param args
	 * @throws IOException
	 * @throws DocumentException
	 * @throws SAXException
	 * @throws InterruptedException
	 */
	public static void main(String[] args) throws IOException, DocumentException,
		SAXException, InterruptedException {
		SettingUtil util = new SettingUtil();
		String reportName = "百度测试用例";
		util.readFromClassPath("baidu.xml"); //加载元素定位配置文件
		
		//获取Page类，然后获取对应的元素，再进行操作
		BaiduHomePage baiduHomePage = util.getPage(BaiduHomePage.class);
		baiduHomePage.open(); //打开baidu.xml配置文件中配置的页面地址
		baiduHomePage.getKeyword().setValue("淘宝"); //告诉框架文本框要填充的值
		baiduHomePage.getKeyword().fillValue(); //向文本框中填充值
		baiduHomePage.getSearchBut().click(); //点击搜索按钮
		
		Thread.sleep(3000);
		
		util.close(); //关闭框架
		String htmlContent = "<!DOCTYPE html>\n" +
				"<html lang=\"en\">\n" +
				"<head>\n" +
				"    <meta charset=\"UTF-8\">\n" +
				"    <title>Title</title>\n" +
				"</head>\n" +
				"<body>\n" +
				"<h1>"+reportName+"</h1>\n"+
				"    <table><tr><td>测试结果<td/></tr><tr><td style = 'background:greed;'>成功<td/></tr></table>\n" +
				"    <a href=\"/openBaidu\">打开百度</a>\n" +
				"</body>\n" +
				"\n" +
				"\n" +
				"\n" +
				"\n" +
				"\n" +
				"\n" +
				"</html>";
		FileUtils.createFile("E:\\Hello\\report\\baidu.html",htmlContent);
	}

}